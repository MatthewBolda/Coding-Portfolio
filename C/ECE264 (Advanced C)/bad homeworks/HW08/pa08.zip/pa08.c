#include <stdio.h>
#include <stdlib.h>
#include "pa08.h"

#ifndef CDOUBLE
void createDouble(char * string,DoubleVar* var,int index,bool dot,int len)
{

	if(i < lens)
		{
				
		createDouble(word, var, 0, dot, i+1)
		}
		 
		
	


}
#endif

#ifndef CVID
void createVID(char * string,VIDVar * var,int index,int len)
{
	
}
#endif

